﻿using ExamWeb.Data;
using ExamWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace ExamWeb.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ApplicationDbContext _db;
        public CategoryController(ApplicationDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            return View();
        }

        //Get Create
        public IActionResult Create()
        {

            return View();
        }

        //Post Create

        [ValidateAntiForgeryToken]
        [HttpPost]
        public IActionResult Create(Category obj)
        {
            if (ModelState.IsValid)
            {
                _db.categories.Add(obj);
                _db.SaveChanges();
                return RedirectToAction("index");
            }
            return View();
        }


        //Get Edit
        public IActionResult Edit(int id)
        {
            List<Category> CtList = _db.categories.ToList();
            ViewBag.Categorytbl = new SelectList(CtList, "CategoryId", "Name");

            var category = _db.categories.Find(id);
            ViewBag.id = category.ParentCategoryId;
            return View(category);
        }

        //Post Edit
        [ValidateAntiForgeryToken]
        [HttpPost]
        public IActionResult Edit(Category obj)
        {
            if (ModelState.IsValid)
            {
                _db.categories.Update(obj);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(obj);
        }


        //Get Delete
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var categoryFromDb = _db.categories.Find(id);

            if (categoryFromDb == null)
            {
                return NotFound();
            }

            return View(categoryFromDb);
        }

        //Post Delete

        [ValidateAntiForgeryToken, ActionName("Delete")]
        [HttpPost]
        public IActionResult DeletePost(Category obj)
        {

            var check = _db.categories.Where(modal => modal.ParentCategoryId == obj.CategoryId).ToList();
            foreach (var x in check)
            {
                var subchild = _db.categories.Where(data => data.ParentCategoryId == x.CategoryId).ToList();
                _db.RemoveRange(subchild);
            }


            _db.categories.RemoveRange(check);

            _db.categories.Remove(obj);
            _db.SaveChanges();
            return RedirectToAction("Index");


        }

        //Get SubCategoryCreate
        public IActionResult SubCreate(int id)
        {
            ViewBag.Pid = id;
            return View();

        }

        //Post SubCategoryCreate

        [ValidateAntiForgeryToken]
        [HttpPost]
        public IActionResult SubCreate(Category obj)
        {
            if (ModelState.IsValid)
            {
                _db.categories.Add(obj);
                _db.SaveChanges();
                return RedirectToAction("index");
            }
            return View();
        }

















        #region API CALLS
        [HttpGet]
        public IActionResult GetAll()
        {
            var categoryList = _db.categories.ToList();
            return Json(new { data = categoryList });
        }
        #endregion
    }
}
