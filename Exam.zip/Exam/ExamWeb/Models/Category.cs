﻿using System.ComponentModel;

namespace ExamWeb.Models
{
    public class Category
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        [DisplayName("Active Status")]
        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; } = DateTime.Now;
        public DateTime ModifiedOn { get; set; } = DateTime.Now;
        public int? ParentCategoryId { get; set; }
    }
}
